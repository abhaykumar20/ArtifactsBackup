import com.sap.gateway.ip.core.customdev.util.Message

def Message processData(Message message) {
    // Assume base64 content is in message body as a string
    def body = message.getBody(String)
    
    // Remove all line breaks and carriage returns
    def cleanedBase64 = body.replaceAll(/[\r\n]+/, "")
    
    // Set cleaned base64 string back into body or property
    message.setBody(cleanedBase64)
    
    // OR if you want to store in a header/property instead, use:
    // message.setProperty("cleanedBase64", cleanedBase64)
    
    return message
}
