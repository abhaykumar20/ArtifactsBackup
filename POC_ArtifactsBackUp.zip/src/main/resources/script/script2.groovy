import com.sap.gateway.ip.core.customdev.util.Message

def Message processData(Message message) {
    def body = message.getBody(String)

    // Regex to extract the access token
    def matcher = body =~ /"access_token"\s*:\s*"([^"]+)"/

    if (matcher.find()) {
        def accessToken = matcher.group(1)

        // Save token as property
        message.setProperty("AccessToken", accessToken)

        // Set token in Authorization header
        def headers = message.getHeaders()
        headers.put("Authorization", "Bearer " + accessToken)
        message.setHeaders(headers)
    } else {
        // Optional: handle case when token not found
        throw new RuntimeException("Access token not found in response.")
    }

    return message
}
